CocoPure Website
================

Open index.html in a browser to view the website.

Included:
- CocoPure Diet Drink — ₹49 — 250 ml
- Lemon Detox Water — ₹49 — 500 ml
- Product ingredients and nutrition information supplied by the business
- WhatsApp ordering links for 8143575709
- Phone: 8143575709
- Email: cocopurepvt@gmail.com
- Address: Bussapur Village, Siddipet, Pincode 502114
- Manufacturer/Marketer: cocopure
- FSSAI/Licence: 23626043000220

All images are included in the images folder.
